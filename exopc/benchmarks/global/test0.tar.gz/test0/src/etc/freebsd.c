/*
 * freebsd.c -- lcc driver definitions for FreeBSD-2.x.x.
 */

#include <string.h>
char *cpp[] = {"/usr/libexec/cpp",
	"-undef", "-nostdinc", "-lang-c", "-U__GNUC__",
	"-D_POSIX_SOURCE", "-D__STDC__", "-D__STRICT_ANSI__",
	"-Dunix", "-Di386", "-DFreeBSD",
	"-D__unix__", "-D__i386__", "-D__FreeBSD__",
	"$1", "$2", "$3", 0};

char *include[] = {"-I/usr/local/include/ansi", "-I/usr/include", 0};

char *com[] = {"/usr/local/lib/rcc", "-target=x86-freebsd",
	"$1", "$2", "$3", 0};

char *as[] = {"/usr/bin/as", "-o", "$3", "$1", "$2", 0};

char *ld[] = {"/usr/bin/ld", "", "-estart", "-dc", "-dp", "-o", "$3",
	"/usr/lib/crt0.o", "$1", "$2", "",
	"-lm", "", "-lc", "", "",
#if 0
	"-lgcc",
#endif
	0};

int 
option(arg)
	char *arg;
{
	if (strcmp(arg, "-g") == 0) {}
	else if (strcmp(arg, "-p") == 0) {
		ld[8] = "/usr/lib/gcrt0.o";
		ld[14] = "-lc_p";
	} 
	else if (strcmp(arg, "-b") == 0 &&
		 access("/usr/local/lib/bbexit.o", 4) == 0)
		ld[11] = "/usr/local/lib/bbexit.o";
	else
		return 0;
	return 1;
}
